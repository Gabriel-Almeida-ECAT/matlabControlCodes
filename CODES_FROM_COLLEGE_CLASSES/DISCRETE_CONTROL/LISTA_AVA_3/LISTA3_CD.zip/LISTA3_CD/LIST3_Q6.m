close all;
clc; clear all;

% para fazer com que o sistema siga referência é preciso
% acrescentar um integrador ao mesmo

%% sistema

A = [0.8815 0.4562;...
     -0.4562 0.7903];

B = [0.1185;...
     0.4562];

C = [1 0];

D = [];

SS2 = ss(A, B, C, D)

Ts = 1
SS2_z = c2d(SS2, Ts,'zoh')

G = SS2_z.A;
H = SS2_z.B;
C = SS2_z.C;

%% calculo dos polos desejados
Pd_z  = [0.6 + i*0.3; 0.6 - i*0.3]


%% Alocacao dos polos
%polos discretos deesjados
[K,precision] = place(G,H,Pd_z);

disp('Ganho K')
disp(K)

% Checar resposta
disp('Polos de malha fechada')
disp(eig(G-H*K))


%% verificacao resposta
step(ss((G-H*K), H, C, D, Ts))